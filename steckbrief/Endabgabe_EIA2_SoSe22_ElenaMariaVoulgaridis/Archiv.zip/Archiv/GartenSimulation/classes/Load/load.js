var GardenSimulation;
(function (GardenSimulation) {
    class Load {
        static loading() {
            Load.ananasS = document.getElementById("ananasS");
            Load.ananasM = document.getElementById("ananasM");
            Load.ananasB = document.getElementById("ananasB");
            Load.blueberryS = document.getElementById("blueberryS");
            Load.blueberryM = document.getElementById("blueberryM");
            Load.blueberryB = document.getElementById("blueberryB");
            Load.melonS = document.getElementById("melonS");
            Load.melonM = document.getElementById("melonM");
            Load.melonB = document.getElementById("melonB");
            Load.raspberryS = document.getElementById("raspberryS");
            Load.raspberryM = document.getElementById("raspberryM");
            Load.raspberryB = document.getElementById("raspberryB");
            Load.strawberryS = document.getElementById("strawberryS");
            Load.strawberryM = document.getElementById("strawberryM");
            Load.strawberryB = document.getElementById("strawberryB");
            Load.dropS = document.getElementById("water1");
            Load.dropM = document.getElementById("water2");
            Load.dropB = document.getElementById("water3");
            Load.fertilizS = document.getElementById("fertilizer1");
            Load.fertilizM = document.getElementById("fertilizer2");
            Load.fertilizB = document.getElementById("fertilizer3");
            Load.bug = document.getElementById("bug");
            Load.empty = document.getElementById("empty");
        }
    }
    GardenSimulation.Load = Load;
})(GardenSimulation || (GardenSimulation = {}));
//# sourceMappingURL=load.js.map